mrjob.protocol - input and output
=================================

.. automodule:: mrjob.protocol

.. autoclass:: JSONProtocol
.. autoclass:: JSONValueProtocol
.. autoclass:: PickleProtocol
.. autoclass:: PickleValueProtocol
.. autoclass:: RawProtocol
.. autoclass:: RawValueProtocol
.. autoclass:: ReprProtocol
.. autoclass:: ReprValueProtocol
