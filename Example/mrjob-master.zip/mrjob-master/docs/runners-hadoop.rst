mrjob.hadoop - run on your Hadoop cluster
=========================================

.. py:module:: mrjob.hadoop
.. autoclass:: HadoopJobRunner

.. automethod:: mrjob.hadoop.HadoopJobRunner.__init__

Utilities
---------

.. autofunction:: hadoop_log_dir
.. autofunction:: find_hadoop_streaming_jar
.. autofunction:: fully_qualify_hdfs_path

