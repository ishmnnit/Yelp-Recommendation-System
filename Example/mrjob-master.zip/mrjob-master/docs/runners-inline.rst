mrjob.inline - debugger-friendly local testing
==========================================================

.. py:module:: mrjob.inline

.. autoclass:: InlineMRJobRunner

.. automethod:: mrjob.inline.InlineMRJobRunner.__init__
