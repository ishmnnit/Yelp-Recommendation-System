mrjob.local - simulate Hadoop locally with subprocesses
=======================================================

.. py:module:: mrjob.local

.. autoclass:: LocalMRJobRunner

.. automethod:: mrjob.local.LocalMRJobRunner.__init__
