mrjob.compat - Hadoop version compatibility
===========================================

.. automodule:: mrjob.compat
	:members:
