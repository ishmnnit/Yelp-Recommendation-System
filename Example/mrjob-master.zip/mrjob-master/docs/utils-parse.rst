mrjob.parse - log parsing
=========================

.. automodule:: mrjob.parse
    :members:
