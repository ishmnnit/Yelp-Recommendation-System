mrjob.retry - retry on transient errors
=======================================

.. py:module:: mrjob.retry
.. autoclass:: mrjob.retry.RetryWrapper
.. automethod:: mrjob.retry.RetryWrapper.__init__
