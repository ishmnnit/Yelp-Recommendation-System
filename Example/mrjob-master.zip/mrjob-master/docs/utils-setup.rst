mrjob.setup - job environment setup
===================================

.. automodule:: mrjob.setup
    :members:
