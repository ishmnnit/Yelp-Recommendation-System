mrjob.util - general utility functions
======================================

.. automodule:: mrjob.util
    :members:
